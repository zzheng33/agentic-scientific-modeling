#!/bin/bash
set -euo pipefail
BUNDLE_ROOT=/home/zhong.zheng/agentic-runs/ptychi_001/benchmark-v002-gh200
export BUNDLE_ROOT
MODULE_PATH=/soft/modulefiles
export CONDA_ENV=ptychopinn_torch_arm

set +u
if ! command -v module >/dev/null 2>&1 && [[ -f /etc/profile.d/modules.sh ]]; then
  source /etc/profile.d/modules.sh
fi
module use "$MODULE_PATH"
module load cuda/12.9.1
module load conda/nvidia/suse15.6/2025.01-11
hash -r
MODULE_PYTHON="$(command -v python)"
CONDA_BASE="$(dirname "$(dirname "$MODULE_PYTHON")")"
source "$CONDA_BASE/etc/profile.d/conda.sh"
conda activate "$CONDA_ENV"
hash -r
set -u

PYTHON_BIN="${PYTHON_BIN:-$(command -v python)}"
APP_ROOT=/home/zhong.zheng/agentic-runs/ptychi_001/benchmark-v002-gh200/application
export PYTHONPATH="$APP_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
export APPLICATION_ROOT="$APP_ROOT"
export POWER_MONITOR_SCRIPT=/home/zhong.zheng/PtychoPINN/scripts/monitor_gpu_power.py
export ACCELERATOR_DEVICE=cuda
export POWER_VENDOR=nvidia
export POWER_DEVICES=0
export POWER_INTERVAL_S=0.2
cd "$BUNDLE_ROOT"
mkdir -p results
module list 2>&1 || true
export PYTHON_BIN
"$PYTHON_BIN" -c 'import torch; assert torch.cuda.is_available(); x=torch.empty(1, device='"'"'cuda'"'"'); print(torch.cuda.get_device_name(0), x.device)'
bash "$BUNDLE_ROOT/benchmark_job.sh"
