#!/bin/bash
set -euo pipefail
BUNDLE_ROOT=/home/zhong.zheng/agentic-runs/ptychi_001/benchmark-v002-gh200
MODULE_PATH=/soft/modulefiles
export CONDA_ENV=ptychopinn_torch_arm

set +u
if ! command -v module >/dev/null 2>&1 && [[ -f /etc/profile.d/modules.sh ]]; then
  source /etc/profile.d/modules.sh
fi
module use "$MODULE_PATH"
module load cuda/12.9.1
module load conda/nvidia/suse15.6/2025.01-11
hash -r
MODULE_PYTHON="$(command -v python)"
CONDA_BASE="$(dirname "$(dirname "$MODULE_PYTHON")")"
source "$CONDA_BASE/etc/profile.d/conda.sh"
conda activate "$CONDA_ENV"
hash -r
set -u

PYTHON_BIN="${PYTHON_BIN:-$(command -v python)}"
APP_ROOT=/home/zhong.zheng/agentic-runs/ptychi_001/benchmark-v002-gh200/application
export PYTHONPATH="$APP_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
export APPLICATION_ROOT="$APP_ROOT"
export BUNDLE_ROOT PYTHON_BIN
cd "$BUNDLE_ROOT"
bash "$BUNDLE_ROOT/dataset_generation.sh"
test -s "$BUNDLE_ROOT/datasets/dataset_manifest.json"
"$PYTHON_BIN" -c 'import json,sys; json.load(open(sys.argv[1], encoding="utf-8"))'   "$BUNDLE_ROOT/datasets/dataset_manifest.json"
