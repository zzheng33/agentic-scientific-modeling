#!/bin/bash
set -euo pipefail
BUNDLE_ROOT=/home/zhong.zheng/agentic-runs/ptychi_001/benchmark-v002-gh200
PYTHON_BIN=/home/zhong.zheng/venv/bin/python
APP_ROOT=/home/zhong.zheng/agentic-runs/ptychi_001/benchmark-v002-gh200/application
export PYTHONPATH="$APP_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
export APPLICATION_ROOT="$APP_ROOT"
export BUNDLE_ROOT PYTHON_BIN
cd "$BUNDLE_ROOT"
"$PYTHON_BIN" -c 'import h5py,numpy; print("dataset runtime:", numpy.__version__, h5py.__version__)'
bash "$BUNDLE_ROOT/dataset_generation.sh"
test -s "$BUNDLE_ROOT/datasets/dataset_manifest.json"
"$PYTHON_BIN" -c 'import json,sys; json.load(open(sys.argv[1], encoding="utf-8"))'   "$BUNDLE_ROOT/datasets/dataset_manifest.json"
